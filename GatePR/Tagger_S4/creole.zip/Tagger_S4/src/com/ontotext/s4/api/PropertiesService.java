package com.ontotext.s4.api;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * Class that loads simple properties file.
 * @author YavorPetkov
 */
public class PropertiesService {

	private static Logger log = Logger.getLogger(PropertiesService.class);
	private Properties properties;

	public PropertiesService(String propertiesFile) {
		properties = new Properties();
		InputStream is = null;
		try {
			is = new FileInputStream(propertiesFile);
		} catch (FileNotFoundException e1) {
			log.error(e1);
		}
		try {
			properties.load(is);
		} catch (IOException e) {
			log.error("Could not load" + propertiesFile+
					"Initialization failed. Details follow.", e);
			return;
		}
	}

	public String getProperty(String key) {
		return properties.getProperty(key);	
	}
}
