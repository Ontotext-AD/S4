package com.ontotext.s4.api;

import gate.creole.ExecutionException;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.Charset;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

/**
 * Sends document for processing to the S4 Rest Service endpoint.
 * @author YavorPetkov
 */
public class S4ServiceClient {
	/**
	 * This is an HTTP connection.
	 */
	private CloseableHttpClient closeableHttpClient;

	/**
	 * Credential for S4
	 */
	private String apiKey;
	private String apiPass;

	/**
	 * URL to the S4 Rest Service endpoint
	 */
	private String endpointUrl;

	/**
	 * Constructor
	 * 
	 * @param endpointUrl
	 *             URL to the S4 Rest Service endpoint
	 * @param apiKey
	 *            apiKey for the S4
	 * @param apiPass
	 *            apiPass for the S4
	 */
	public S4ServiceClient(String endpointUrl, String apiKey, String apiPass) {
		if(endpointUrl.endsWith("/")){
			endpointUrl=endpointUrl.substring(0,endpointUrl.lastIndexOf("/"));
		}
		this.endpointUrl = endpointUrl;
		this.apiKey = apiKey;
		this.apiPass = apiPass;
	}

	/**
	 * Sets up an authentication
	 */
	public static HttpClientContext setupContext(String keyId, String password) {
		HttpClientContext ctx = HttpClientContext.create();
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
				keyId, password);
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(AuthScope.ANY, creds);
		ctx.setCredentialsProvider(credsProvider);
		return ctx;
	}

	/**
	 * Checks the endpoint and the authentication.
	 * 
	 * @return True if endpoint and authentication are right.
	 * @throws Exception Check Status code and go to S4 docs for more information.
	 */
	public boolean checkEndpoint() throws Exception {
		closeableHttpClient = HttpClients.createDefault();
		HttpGet get = new HttpGet(endpointUrl.substring(0,
				endpointUrl.lastIndexOf("/")));
		CloseableHttpResponse response = closeableHttpClient.execute(get,
				setupContext(apiKey, apiPass));
		int statusCode = response.getStatusLine().getStatusCode();
		response.close();
		if (statusCode != 200) {
			throw new Exception("Status code: " + statusCode);
		} else {
			return true;
		}
	}

	/**
	 *Executes one request.
	 * 
	 * @param doc
	 *            String with the text we want to annotate
	 * @return response gate/xml format
	 * @throws ExecutionException
	 */
	public String execute(String doc) throws ExecutionException {

		// checks if this is the first document
		if (closeableHttpClient == null) {
			closeableHttpClient = HttpClients.createDefault();
		}

		// Initialize a post request
		HttpPost post = new HttpPost(endpointUrl);

		// Setup the posts headers
		post.setHeader("Content-Type", "application/json");
		post.setHeader("Accept", "application/gate+xml");
		post.setHeader("Accept-Encoding", "gzip");

		// Prepare request body
		ProcessingRequest pr = new ProcessingRequest();
		pr.setDocument(doc);
		pr.setDocumentType("text/plain");
		String text;
		try {
			text = pr.toJSON();
		} catch (IOException e) {
			throw new ExecutionException(
					"Some problem with request preparation", e);
		}

		// Add body to the post
		post.setEntity(new StringEntity(text, Charset.forName("UTF-8")));

		// execute post request
		CloseableHttpResponse response;
		try {
			response = closeableHttpClient.execute(post,
					setupContext(apiKey, apiPass));
		} catch (IOException e) {
			throw new ExecutionException("Can't post request", e);
		}

		int statusCode = response.getStatusLine().getStatusCode();
		String endString;
		try {
			endString = getContent(response);
		} catch (IOException e) {
			throw new ExecutionException("Can't parse response.", e);
		}
		try {
			response.close();
		} catch (IOException e) {
			throw new ExecutionException("Can't close response connection", e);
		}
		if (statusCode == 200) {
			return endString;
		} else {
			throw new ExecutionException(statusCode + "");
		}
	}

	/**
	 * Helper method which collects the response's body as a string
	 * 
	 * @param response
	 *            the HttpResponse whose content we want to collect
	 * @return the String value of the response body
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	private static String getContent(HttpResponse response)
			throws IllegalStateException, IOException {
		InputStream content = response.getEntity().getContent();
		StringWriter sw = new StringWriter();
		IOUtils.copy(content, sw, "UTF-8");
		return sw.toString();
	}
}
