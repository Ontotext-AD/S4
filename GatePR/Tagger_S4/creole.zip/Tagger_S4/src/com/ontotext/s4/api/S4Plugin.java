package com.ontotext.s4.api;

import java.io.Serializable;
import java.net.URL;
import java.util.Set;

import gate.AnnotationSet;
import gate.Document;
import gate.Factory;
import gate.ProcessingResource;
import gate.Resource;
import gate.corpora.DocumentContentImpl;
import gate.creole.AbstractLanguageAnalyser;
import gate.creole.ExecutionException;
import gate.creole.ResourceInstantiationException;

/**
 * Main entry point for the S4 GATE PR plug-in.
 * @author YavorPetkov
 */
public class S4Plugin extends AbstractLanguageAnalyser implements
		ProcessingResource, Serializable {

	private static final String apiKey = "apiKey";
	private static final String apiPass = "apiPass";

	private static final long serialVersionUID = -1754780486191588663L;

	private Boolean debug = false;

	/**
	 * The API Client
	 */
	private S4ServiceClient s4ServiceClient;

	/**
	 * The URL of the S4 REST service
	 * 
	 */
	private S4Endpoints s4URL;

	/**
	 * URL to the Rest Service.Use this only if we change S4 rest API client
	 * Endpoints
	 */
	private String restServiceUrlString;

	/**
	 * Configuration file with apiKey and apiPass
	 */
	private URL configFileURL;

	/**
	 * apiKey and apiPass
	 */
	private PropertiesService configFile;

	/**
	 * Initialize S4 Gate PR
	 */
	public Resource init() throws ResourceInstantiationException {

		//debug
		if (getDebug() == true) {
			System.out.println(getConfigFileURL().getFile());
		}

		// check configuration file
		try {
			configFile = new PropertiesService(getConfigFileURL().getFile());
		} catch (Exception e) {
			throw new ResourceInstantiationException(
					"Probably you forgot S4.config file.", e);
		}

		// debug
		if (getDebug() == true) {
			System.out.println("Initializing connection.");
			System.out.println("Enum s4url:" + getS4URL().toString());
			System.out.println("String s4url:" + getRestServiceUrlString());
		}

		// Initialize client if it is needed.
		if (s4ServiceClient == null) {
			s4ServiceClient = new S4ServiceClient(restService(),
					configFile.getProperty(apiKey),
					configFile.getProperty(apiPass));
		}
		
		//check endpoint
		try {
			s4ServiceClient.checkEndpoint();
		} catch (Exception e) {
			throw new ResourceInstantiationException(e);
		}

		return this;
	}

	/**
	 * The execute method
	 */
	public void execute() throws ExecutionException {

		// get document
		String text = ((DocumentContentImpl) getDocument().getContent())
				.toString();

		// check if api is loaded
		if (s4ServiceClient == null) {
			s4ServiceClient = new S4ServiceClient(restService(),
					configFile.getProperty(apiKey),
					configFile.getProperty(apiPass));
		}

		String response = null;

		//debug
		if (getDebug() == true) {
			System.out.println("Send " + getDocument().getName()
					+ " for processing.");
		}

		// send the document for processing
		response = s4ServiceClient.execute(text);

		//debug
		if (getDebug() == true) {
			System.out
					.println("Copy annotations to " + getDocument().getName());
		}

		// copy annotations
		try {
			copyAnnotations(response, document);
		} catch (ResourceInstantiationException e) {
			throw new ExecutionException(e);
		}
	}

	/**
	 * Reinitialize the Processing Resource
	 */
	@Override
	public void reInit() throws ResourceInstantiationException {
		s4ServiceClient = null;
		init();
	}

	/**
	 * 
	 * @param response
	 *            - gate/xml from where we want to copy annotations
	 * @param document
	 *            - gate document where we want to add annotations
	 * @throws ResourceInstantiationException
	 * 			- if we can't create tempDoc
	 */
	private void copyAnnotations(String response, Document document)
			throws ResourceInstantiationException {
		
		//create temporary doc
		Document tempDoc  = (Document) Factory.newDocument(response);

		// get all annotations sets names
		Set<String> annotationSetNames = tempDoc.getAnnotationSetNames();
		
		//copy 'default' annotations
		AnnotationSet newAnnotations = tempDoc.getAnnotations();
		
		//copy the rest annotations
		for (String annotationSetName : annotationSetNames) {
			newAnnotations.addAll(tempDoc.getAnnotations(annotationSetName));
		}
		
		//debug
		if (getDebug() == null) {
			System.out
					.println("Number of annotations:" + newAnnotations.size());
		}

		//add all new annotations to the old gate document
		document.getAnnotations().addAll(newAnnotations);

		//remove temporary document
		Factory.deleteResource(tempDoc);

	}

	/**
	 * Choose what source to use for the rest service URL.
	 * @return String with the S4 rest service URL.
	 */
	private String restService() {
		return getRestServiceUrlString() != null ? getRestServiceUrlString()
				: getS4URL().toString();
	}

	public S4Endpoints getS4URL() {
		return s4URL;
	}

	public void setS4URL(S4Endpoints s4url) {
		s4URL = s4url;
	}

	public URL getConfigFileURL() {
		return configFileURL;
	}

	public void setConfigFileURL(URL configFileURL) {
		this.configFileURL = configFileURL;
	}

	public String getRestServiceUrlString() {
		return restServiceUrlString;
	}

	public void setRestServiceUrlString(String restServiceUrlString) {
		this.restServiceUrlString = restServiceUrlString;
	}

	public Boolean getDebug() {
		return debug;
	}

	public void setDebug(Boolean debug) {
		this.debug = debug;
	}
}
