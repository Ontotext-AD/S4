#!/bin/bash
java -jar dbaas-loader.jar $*
